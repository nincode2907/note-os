# Manifest and service-worker audit

- Manifest route: `/manifest.webmanifest`; name and short name are `noteOS`; scope and start URL are `/`; display is `standalone`; icons include 192px, 512px, and maskable 512px PNGs.
- Apple metadata: `apple-mobile-web-app-capable`, title, status bar style, and 180px Apple icon are emitted by the root layout.
- Update behavior: `/sw.js` is served as JavaScript with `no-store`; registration uses `updateViaCache: 'none'`; app launch and foreground call `registration.update()`.
- Cache naming is explicitly versioned (`noteos-pwa-shell-0001`). Install pre-caches the app home, offline/transition pages, manifest, and icons. Activation retains at most the newest two noteOS cache generations and removes the known prior `noteos-gate1-shell-v1` cache.
- Runtime policy: network first for app navigation and RSC shell requests; hashed Next static assets and icons use cache first; fallback is a locally cached offline page. Dynamic cache entries are capped at 80.
- Privacy policy: `/api/` is excluded; `/api/v1/sync/*` is explicitly network-only with `cache: 'no-store'`. Responses with `private` or `no-store` are not cached except `/notes/:id`, which is client-only and marked `X-NoteOS-Offline-Shell: client-only`. Its note data is loaded from IndexedDB after render.
- Synthetic browser evidence confirmed zero cached Sync API requests and no synthetic private note marker in cached response bodies. Offline reload of a warmed client-only note route kept the editor usable.

## Cache lifecycle boundary

The worker preserves only its current and immediately previous cache version so an update can complete without losing the active shell. It does not delete arbitrary Cache Storage names or other applications’ caches.
