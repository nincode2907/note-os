# Rollback

1. Revert the Phase 08.3 source commit on `main` using a new revert commit. Do not reset or rewrite the branch.
2. Rebuild and redeploy the noteOS Web image through its normal Compose procedure. Do not run `docker compose down -v` and do not remove `noteos_noteos_sync`, `noteos_dedicated_tailscale_state`, any personal browser data, or MemoryOS resources.
3. The deployed service worker uses versioned cache names and will activate the worker shipped by the reverted application. Keep the current and previous caches until that activation completes; do not clear browser storage.
4. Remove only the review ZIP if the owner wants the artifact removed. No production database migration or data deletion was part of this phase.
