# Owner checklist — Phase 08.3 on a physical iPhone

This checklist is still **PENDING**. Codex did not test on an iPhone.

1. On the physical iPhone, enable Tailscale and open `https://noteos.tail913fb3.ts.net` in Safari.
2. Confirm HTTPS loads, then use Share → Add to Home Screen. Launch noteOS from the new Home Screen icon.
3. Confirm it opens without Safari browser chrome. In Sync Setup, check the local note and recording counts before pairing or enrollment. Safari and the Home Screen app may show different counts; neither should be cleared or copied automatically.
4. Pair the Home Screen installation separately if requested. Verify approved server notes appear. Do not bulk-enroll existing notes; approve only notes you choose.
5. Turn off Wi-Fi and cellular data (or otherwise disconnect from the Tailnet). Create a disposable test note, close/relaunch the Home Screen app, and confirm the note remains readable and editable.
6. Re-enable connectivity and Tailscale. Keep noteOS open; verify the test note syncs without pressing Sync Now and appears in Mac Chrome.
7. Edit the disposable note in Mac Chrome and confirm the change returns to the PWA. Check that the status distinguishes pending, connection waiting, synced text, review-needed conflicts, and local-only audio.
8. Return to Safari and confirm its original local note count and data are unchanged. Confirm MemoryOS remains available.

Record the iPhone model, iOS version, network used, and PASS/FAIL for each step. Do not send note contents or pairing codes in the report.
