# noteOS — PWA Icon Update Review

## Scope and source

- Repository: `nincode2907/note-os`
- Baseline: `dc1e2c90cb4c97c24367a5a88d9aaf5d68d59d9e`
- Source commit: `59b525a0399e7173acd8461fcdff422c8360149c`
- Branch: `main`
- Master: `assets/branding/noteos-icon-master.png`, 1024×1024 PNG. SHA-256: `a919ce8fb029154b26b326e0d90dcbb6dd0c5b544b5fe6a91350424826583caa`.

The requested master path was absent at the start of the task. It is populated from the 1024×1024 noteOS master created in the immediately preceding icon task. The folded page, lowercase `n`, terracotta color and writing rules preserve the current noteOS identity. `assets/branding/noteos-icon-maskable.svg` keeps the same mark scaled inside the center safe area.

## Changed behavior

- Replaced the deployed PWA PNGs at their existing manifest URLs: 192×192, 512×512 and maskable 512×512.
- Added `public/apple-touch-icon.png` at 180×180 and refreshed the existing `/apple-icon.png` alias.
- Set the install name and short name to `Note OS`; Next.js application and Apple web app metadata use the same title.
- Advanced the service-worker shell cache key to `noteos-pwa-shell-0002`. The worker pre-caches the new touch icon and retains the previous shell cache during activation (up to the existing two-cache retention policy).
- Left `app/icon.svg`/favicon, manifest ID, URLs for the three PWA icons, IndexedDB schema, Sync enrollment, Text Sync protocol and local application data behavior unchanged.

## Verification

- Focused PWA icon contract: 3 tests pass.
- Complete Web app/server regression set: **221 passed, 0 failed**. Includes PWA contract, Text Sync, Sync conflict/retry, IndexedDB migration and Archive V2 suites.
- TypeScript: `tsc --noEmit`, exit 0.
- Next.js 16.4.2 production build: exit 0; `/manifest.webmanifest` generated successfully.
- HTTP smoke test on local `next start` at `127.0.0.1:3187`: manifest and all icon URLs returned HTTP 200; image MIME types and PNG dimensions were verified; manifest name and short name were `Note OS`.
- Isolated Chromium `156.0.8078.4` PWA smoke: activated `/sw.js`, populated cache 0002, retained the seeded 0001 cache, served offline home navigation and icon, and preserved a synthetic IndexedDB sentinel. This test used a fresh temporary browser context and no user data.
- Preview: `previews/pwa-icon-contact-sheet.png`. Focused regression, build, typecheck and offline browser logs are in `evidence/`.
- Runtime/browser coverage is desktop Chromium only. No physical iPhone or installed iOS PWA claim is made.

## Production and data safety

No production deployment, container recreation, Docker operation, production database access, site-data clearing, service-worker unregister, real note, Audio Sync, AI feature, MemoryOS change or Sync-enrollment change occurred. The temporary local Next.js server on port 3187 was stopped after testing. Existing unrelated Git deletions and the prior `public/icons/noteos-v2/` untracked folder were excluded from the source commit.

## Deployment instructions — not executed

After owner approval, release commit `59b525a0399e7173acd8461fcdff422c8360149c` through the project's normal approved Web release process. Confirm `/manifest.webmanifest`, `/icons/noteos-192.png`, `/icons/noteos-512.png`, `/icons/noteos-maskable-512.png`, `/apple-touch-icon.png` and `/sw.js` are served from the same release. Existing PWA clients should open while online and allow the service-worker update to complete; do not clear site data, unregister the worker or reset IndexedDB. The install label may be refreshed by the OS when the installed PWA next updates its metadata; iOS behavior still needs a real-device check.

## Rollback instructions — not executed

If rollback is approved, revert the source commit, restore the prior icon assets and metadata, and set the rollback service-worker cache key to a new generation such as `noteos-pwa-shell-0003` (do not reuse an old cache key). Release through the same approved Web process and let clients update online. Preserve IndexedDB and the existing service-worker registration; no production container recreation is required for these static/Web changes.
