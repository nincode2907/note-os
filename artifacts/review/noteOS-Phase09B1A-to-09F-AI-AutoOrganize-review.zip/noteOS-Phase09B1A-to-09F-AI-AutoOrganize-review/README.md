# noteOS — AI Auto Organize: Phase 09B-1A → 09F (gói review)

**Baseline:** `ccf92c7` (origin/main) → **HEAD:** `da791eb` · 6 commit đã push lên `main` · 52 file, +4.470 / −110 dòng.
**Phạm vi dữ liệu:** chỉ dữ liệu synthetic và provider giả lập. Không migration production, không deploy, không bật inference, không gửi ghi chú thật vào model, không gọi cloud model. Audio Sync vẫn OFF. Không đụng MemoryOS, SoulCore, AI Gateway (codex-server) hay container khác.

## Tổng kết từng phase

| Phase | Kết luận | Commit | Bằng chứng chính |
|---|---|---|---|
| **09B-1A** Cross-process revocation safety | **PASS** | `3630f3c` | Intent ghi trước (fsync) + fence dispatch bền + watchdog huỷ inference đang chạy + reconcile sau crash. 40 cuộc đua revoke đa tiến trình: không suggestion nào được publish; huỷ p50 50 ms / p95 53 ms. |
| **09B-1B** AI Gateway + đánh giá synthetic | **PARTIAL** | `2d4d032` | Adapter STRICT_LOCAL cho Gateway hiện có: từ chối `codex` (cloud), origin không phải loopback, không fallback, cần owner attestation. Benchmark vi/en/ja (30 note, 6 prompt-injection): 0 rò rỉ nội dung nguy hiểm kể cả với model "nghe lời" injection. **Benchmark model thật: BLOCKED.** |
| **09C** AI Suggestions Inbox | **PASS** | `2a08ecf` | Approve/Edit/Reject/Later/Undo; áp dụng qua SaveCoordinator + Text Sync; CAS từng mục giữa thiết bị; E2E Docker cô lập trên Chromium (sáng/tối) + WebKit cỡ iPhone. |
| **09D** Reliability & Recovery | **PASS** | `3055acb` | Kill worker giữa chừng, Gateway sập rồi lên lại, output hỏng, 3 worker song song, audit, retention, backup/rollback chỉ-AI, AI OFF không ảnh hưởng Text Sync, ma trận bảo mật. |
| **09E** Controlled AI Pilot | **BLOCKED — chờ chủ sở hữu duyệt** | `971b279` | Đã sẵn sàng: lệnh migration có xác nhận + backup đã kiểm, preflight chỉ-đọc (go/no-go), giới hạn số note pilot, runbook pilot/dừng/rollback. Chưa chạy gì trên dữ liệu thật. |
| **09F** Semantic Search | **PARTIAL** | `da791eb` | Tìm kiếm thông minh chạy ngay trên thiết bị (vi/en/ja, không gửi gì ra ngoài), fallback từ khoá. Recall@5 0,96 so với 0,44 của bộ lọc hiện tại. **Tầng embedding bằng model: BLOCKED.** |

Kiểm thử cuối: server **144/144**, client **134/134**, TypeScript sạch; E2E trình duyệt 09C và 09F **PASS**.

## Tính năng đã hoạt động (trong source, mặc định OFF)

- Thu hồi quyền AI an toàn đa tiến trình, fail-closed khi SQLite lỗi, crash hoặc control plane không ghi được; lệnh dừng khẩn `INFERENCE_STOP`.
- Worker chạy theo yêu cầu bên trong container web hiện có (không thêm container/service thường trú), gọi Gateway qua `host.docker.internal` với Host header, đúng mô hình MemoryOS đang dùng.
- Inbox gợi ý: category/tag/summary/task/related, có trích dẫn nguồn, độ tin cậy, xem trước thay đổi; AI không tự sửa ghi chú; chống trùng/lỗi thời/xung đột thiết bị; hàng đợi quyết định offline.
- Related notes do server đề xuất (không phải model), chỉ trong các note đang được cấp quyền; thêm `similar_content` theo nghĩa.
- Công cụ vận hành: báo cáo dung lượng/quota, retention (mặc định dry-run), backup `VACUUM INTO`, rollback chỉ-AI, migration có khoá, preflight.
- Smart search trên trang Notes (Smart/Exact), index tăng dần, 5.030 note: truy vấn p50 ~5–7 ms, ~20 MiB.

## Tính năng còn bị khoá

| Khoá | Lý do | Cần gì để mở |
|---|---|---|
| Inference thật | Brief: chỉ mock/fake trước khi được duyệt; Gateway chưa cấu hình backend local | Quyết định 1–3 bên dưới |
| Benchmark model thật (09B-1B) | Như trên | Lệnh có sẵn trong `docs/09B-1B…` |
| Pilot dữ liệu thật (09E) | Cần phê duyệt riêng | Runbook `docs/09E…` |
| Tầng embedding model (09F) | Gateway không có endpoint embeddings; chưa chọn model | Quyết định 9 |
| Cloud provider | Bị từ chối ở cấu hình, schema và admission | Grant riêng tên provider/retention (chưa thiết kế) |

## Blocker và quyết định cần chủ sở hữu phê duyệt

1. **Duyệt chạy model local** trên dữ liệu synthetic, sau đó pilot với 5–10 note (`NOTEOS_AI_PILOT_MAX_NOTES`).
2. **Backend Gateway:** cấu hình `OLLAMA_BASE_URL` trong codex-server (dự án khác, Codex không sửa) hoặc duyệt adapter gọi Ollama trực tiếp. Hiện Gateway chỉ có `codex` (cloud, `state: remote`), còn `ollama` báo `provider_disabled`.
3. **Chọn model** (đã cài `llama3.1` / `llama3.1-fast` 8B ≈ 4,9 GB) và ký attestation chạy local; đặt ngưỡng chất lượng.
4. **Phân loại privacy cho note văn bản:** Text Sync không gán `privacy`; hiện chỉ luồng audio gán `PRIVATE_SERVER`. AI đúng là không coi "thiếu privacy" là đủ điều kiện, nên note thuần văn bản chưa thể dùng AI qua UI. Cần một nút chọn privacy rõ ràng cho từng note.
5. **Cách biểu diễn:** category → tag; summary → khối trích dẫn đầu note; related → dòng "Related: <tiêu đề>" (link canonical phải là http/https và origin khác nhau theo thiết bị).
6. **Retention và backup:** 30 ngày cho nội dung gợi ý đã quyết định, 180 ngày cho audit; lịch xoay vòng backup (backup cũ vẫn giữ text đã purge).
7. **Cửa sổ deploy** rebuild `noteos-web`: Dockerfile ở HEAD trước đây **không build được** (lỗi `COPY /app/lib/...` có từ `ae4fb24`, đã sửa) và nay có thêm module AI.
8. **Nghiệm thu thiết bị thật** Mac + iPhone (Codex không thể khẳng định kết quả trên iPhone thật).
9. **Embedding model** cho 09F (ví dụ `bge-m3` đa ngôn ngữ) và adapter.
10. **Dark mode toàn app** (AI đã theo chế độ hệ thống; phần còn lại của app có 44 màu cứng).

## Lỗi phát hiện và đã sửa trong đợt này

- Thu hồi quyền chỉ chặn trong 1 tiến trình (blocker 09B-0) → sửa ở 09B-1A.
- Revoke bị từ chối do lỗi người gọi vẫn để lại marker và khoá note vĩnh viễn → khôi phục trạng thái.
- `grantNoteConsent` nội bộ chấp nhận note `DEVICE_ONLY` (policy vẫn chặn enqueue) → chặn sớm.
- Model có thể ghép nhãn tag tuỳ ý với một trích dẫn hợp lệ → nhãn tag phải có trong note, category phải thuộc danh mục cố định.
- Panel consent gọi API theo mỗi sự kiện Sync, cạn rate limit 60/phút và inbox hiện "Offline" → throttle; đỉnh còn 34/phút.
- Undo bị từ chối sau mọi chỉnh sửa tiếp theo → đảo ngược đúng node đã chèn.
- Chuẩn hoá dấu tiếng Việt gây nhầm ("đơn" ↔ "dọn", "ôn" ↔ "on") → giữ dấu cho từ một âm tiết.
- Dockerfile không build được (có từ trước) → sửa đường dẫn.

## Runbook

- Pilot, migration, deploy, dừng và rollback: `docs/09E-controlled-pilot-runbook.md`.
- Bảo trì, retention, backup, rollback chỉ-AI: `docs/09D-reliability-recovery.md`.
- Benchmark model thật khi được duyệt: `docs/09B-1B-gateway-adapter-synthetic-eval.md`.

## Nội dung gói

- `docs/`: bản ghi quyết định và kết quả từng phase (tiếng Anh).
- `commits.txt`, `source-diff.stat`, `implementation.diff`: source diff `ccf92c7..da791eb`.
- `evidence/09B-1A … 09F/`: log test, benchmark JSON, ảnh chụp UI, kết quả E2E, quét bảo mật, `npm audit`, preflight.
- `SHA256SUMS`.

## Môi trường đo

macOS 15.7.7 · Apple M2 · 16 GB · Node 24.21.0 (test/host) và Node 22.21.1 (container) · Chromium 156 · WebKit 27.2 (cỡ iPhone 390×844, **không phải iPhone thật**). Trong lúc đo, máy chịu tải ngoài (load average 270–500 do các job Chrome headless của dự án khác), nên số liệu độ trễ chỉ mang tính tham khảo.

## Giới hạn

Không có xoá vật lý an toàn (WAL/backup có thể còn byte đã purge). Điểm chất lượng của generator heuristic và lexicon search là lạc quan, vì cùng một tác giả viết dataset và query. Ảnh WebKit chỉ là bằng chứng mô phỏng thiết bị, không phải thiết bị thật. Có 2 advisory `npm audit` mức moderate từ dependency WatermelonDB cũ, không liên quan AI.
