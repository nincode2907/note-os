# Independent Review Brief — noteOS MVP-02 Local Audio

Review the implementation and evidence in this package against the approved MVP-02 brief. Focus on data safety and hidden lifecycle failures. Do not infer broader compatibility from the tested Chromium environment.

## Review questions

1. **Recording lifecycle:** Can start, pause/resume, stop, duplicate-session prevention, tab navigation, recorder errors and unmount/reload create an invalid state or lose already committed chunks?
2. **Partial durability:** Is the `recording`/`paused`/`complete`/`interrupted`/`failed` state machine truthful? Assess per-tab recovery, the two-minute recording staleness threshold and one-day paused threshold, including suspended tabs and duplicated `sessionStorage` identities.
3. **IndexedDB integrity:** Is the v1 → v2 upgrade additive? Do chunk metadata and Blob writes remain atomic and correctly ordered under quota/transaction failures? Is note deletion’s cascade bounded and transactional?
4. **Lifecycle and races:** Do archive/trash preserve audio? Does permanent note deletion remove all linked chunks atomically after a clear acknowledgement? Consider concurrent tabs and deleting while another recorder is active.
5. **Backup/export:** Is the notes-only v1 backup scope clearly preserved? Does audio export use the stored MIME type safely, and are memory costs and browser download uncertainty communicated?
6. **Privacy and permission:** Is the microphone requested only after an explicit user action? Verify that there is no upload, telemetry or external request path in the audio feature.
7. **Browser evidence:** Distinguish source/unit evidence, fake-media Chromium runtime evidence, synthetic UI Lens rendering, and NOT RUN physical microphone/Safari/iPhone/process-kill/quota-scale claims.

## Review constraints

- The browser suite used Chromium `156.0.8078.4` with its fake media device; it did not open a physical microphone.
- UI Lens used synthetic note text and generated fake audio. The image set covers idle, active recording, saved audio, playback, permission error and interrupted partial audio at desktop and mobile viewports.
- 28 MVP tests, 31 document-engine tests, 8 MVP-02 browser scenarios, 13 MVP-01 regression scenarios, typecheck, production build and 12 UI Lens captures are reported PASS.
- Real microphone, Safari/iPhone, browser eviction, process termination, large/long recordings and quota exhaustion were NOT RUN.
- IndexedDB is chunked at roughly one-second `MediaRecorder` timeslices. Playback/export builds a Blob from all chunks, so temporary memory use scales with the recording size.

Return findings by severity with specific file/function evidence. Identify whether each concern is confirmed from code or needs runtime verification. Give a review verdict and any targeted changes needed before architecture acceptance. Do not select Sync Engine, add STT/cloud features, or initiate MVP-03.
