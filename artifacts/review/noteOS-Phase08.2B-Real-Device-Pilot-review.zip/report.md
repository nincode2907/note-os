# noteOS — Phase 08.2B Real-Device Sync Pilot

**Date:** 2026-10-24 (Asia/Ho_Chi_Minh)  
**Acceptance:** ACCEPTED — owner confirmed all seven real-iPhone pilot scenarios PASS.  
**Evidence attribution:** These seven outcomes are owner-reported after hands-on testing in physical iPhone Safari. Codex did not run browser tests or independently observe the iPhone interactions.

## Owner-confirmed pilot results

| Scenario | Status | Attribution |
|---|---|---|
| HTTPS over cellular with Tailscale | PASS | Owner confirmed physical iPhone Safari. |
| iPhone Safari pairing | PASS | Owner confirmed physical iPhone Safari. |
| iPhone → Mac note sync | PASS | Owner confirmed. |
| Mac → iPhone note sync | PASS | Owner confirmed. |
| Offline → online replay | PASS | Owner confirmed. |
| Concurrent two-device conflict preservation | PASS | Owner confirmed. |
| Persistence after reload/restart | PASS | Owner confirmed device/app persistence. No Docker container restart was performed or claimed. |

The owner’s confirmation is the evidence for these real-device results; no private note content or screenshots were requested or added.

## Read-only runtime verification after acceptance

- `noteos-web-1`: running/healthy; HTTPS homepage returned HTTP 200 and certificate verification result 0.
- Sync API remains enabled. An unauthenticated status request returns HTTP 401, confirming the route is active and authentication is enforced.
- `noteos-tailscale-noteos-1`: running. The current Tailscale configuration and state volume were not changed.
- MemoryOS web returned HTTP 200; API, MySQL, queue and AI worker containers were healthy. No MemoryOS resources were modified.
- Read-only Sync DB summary: schema 2, cursor 7, 3 note records, 2 paired devices and 7 operations. No note content, note IDs, pairing secrets or server epoch were read into this report.
- The prior focused Sync suite result remains 40/40 pass. It was not rerun for this acceptance update. No browser tests were rerun.

## Scope and remaining limits

The Web text-only Sync pilot is **ACCEPTED** for the controlled owner test. The pilot exercised text Sync only. Audio Sync, Expo Native Sync, background Sync on iOS and AI processing are not implemented and remain out of scope. This does not claim full archive compatibility or audio synchronization.

The Sync API is ON for the pilot. The production Sync volume remains in use; no database reset, deletion, or destructive migration was performed. The schema migration was additive and the database was empty before initialization.

## Docker and workspace cleanup

- No task-specific test containers, test volumes or temporary networks were created, so none required removal.
- noteOS Web, Tailscale sidecar, production Sync volume, and all unrelated services remain in place.
- MemoryOS remains healthy and untouched.
- Exactly one Phase 08.2B review ZIP is maintained. Staging files created to refresh it were removed after packaging.

## Git

- Pilot configuration commit: `91f19f3 Add opt-in Phase 08.2B sync pilot profile`.
- The review ZIP was refreshed to capture the owner’s acceptance. Its update commit is reported in the handoff outside this archive.
- Existing unrelated Git changes, including earlier artifact deletions, were preserved and not staged by this update.

No Phase 08.3, Audio Sync, Expo Sync or AI work was started.
