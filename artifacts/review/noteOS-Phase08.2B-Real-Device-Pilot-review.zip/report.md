# noteOS — Phase 08.2B Real-Device Sync Pilot

**Date:** 2026-10-24 (Asia/Ho_Chi_Minh)  
**Status:** PENDING — physical iPhone Safari steps and cross-device note tests have not been completed.

## Results

| Area | Status | Evidence |
|---|---|---|
| Sync API activation | PASS | Opt-in Compose profile applied to `web`; container healthy; authenticated status endpoint returns HTTP 401 before authentication. |
| HTTPS on Mac | PASS | `https://noteos.tail913fb3.ts.net/` returned HTTP 200 with certificate verification result 0. This does not prove the iPhone cellular path. |
| Mac Chrome pairing | PASS | Browser UI confirmed “Mac Chrome — Phase 08.2B”; server had 0 note records at pairing. |
| Mac note create/push/pull | PENDING | No pilot note has been created or enrolled. |
| iPhone Safari over cellular | PENDING | Requires owner interaction on the physical iPhone with Wi-Fi off and Tailscale enabled. |
| iPhone pairing and note sync | PENDING | No iPhone device is paired yet. |
| Offline replay, duplicate prevention, conflicts | PENDING | No real-device scenarios have been run. |
| Restart/reload persistence | PENDING | To verify after pilot records exist. |
| Audio exclusion | PASS (guard only) | UI and protocol describe text-only sync; audio bytes are not transferred and recording-bearing notes are excluded. No audio-bearing pilot note was sent. |
| MemoryOS | PASS | Web returned HTTP 200; API and MySQL were healthy; all inspected MemoryOS services remained running. |

## Database and safety

- The existing production Sync volume was inspected before activation. It had no database or epoch marker before the owner-authorized initialization.
- Initialization created a schema-v1 database on the previously empty volume. The currently built Web image applied migration 002 additively: schema version 2, `server_cursor=0`, and 0 notes/entities, 0 operations, 0 devices before Mac pairing.
- Migration 002 adds `record_json`, migrates metadata inside a transaction, and preserves the server epoch and cursor. No note/entity rows existed to migrate. No database reset or deletion was performed.
- At the latest read-only check: schema 2, cursor 0, 0 note entities, 1 paired device (Mac Chrome), and 0 operations.
- Existing note origins were not inspected or bulk-enrolled. No note is enrolled on either device.
- Sync API is ON for this owner-approved pilot. Tailscale sidecar and state volume were not changed. Production Sync volume remains mounted.
- No task-owned test containers, named volumes, or networks were created. No global Docker cleanup ran. MemoryOS and unrelated resources were left intact.

## Validation and runtime

- Focused Sync test suite: **40 passed, 0 failed** (`npm run test:sync`, Node.js 24.21.0 on macOS; test runtime 801.7 ms).
- Container build: Next.js 16.4.2; runtime image uses Node.js 22.21.1 Alpine. Build completed. Build output reported 2 moderate npm audit findings; they were not changed in this pilot.
- Mac HTTPS certificate verification: result 0; page HTTP 200.
- Unauthenticated Sync status over HTTPS and localhost: HTTP 401, as expected before pairing.
- `noteos-web-1`: running/healthy. `noteos-tailscale-noteos-1`: running. MemoryOS web: HTTP 200; MemoryOS API/MySQL: running/healthy.
- No browser automation is counted as physical iPhone evidence.

## Git

- Commit: `91f19f3 Add opt-in Phase 08.2B sync pilot profile`
- Pushed to `origin/main`; remote was at `b5648ddb` before this commit and push completed successfully.
- The previously existing owner deletions under `artifacts/review/**` were preserved and not staged.

## Owner handoff required

On the physical iPhone:

1. Turn Wi-Fi off, enable cellular and Tailscale, then open `https://noteos.tail913fb3.ts.net/sync` in Safari. Confirm there is no certificate warning.
2. In Mac Terminal, run `docker exec -it noteos-web-1 node sync-server/cli.mjs pair`. Keep the 120-second code private and enter it directly in Safari with label `iPhone Safari — Phase 08.2B`. Do not send the code in chat.
3. Create a disposable note named `08.2B PILOT — iPhone`. In Sync Setup, inspect and select only that exact pilot note; leave all other notes unchecked. Approve it and press Sync now.
4. Report whether the note appears on Mac Chrome. Then Mac-side edit/pull, offline replay, concurrent conflict preservation, and restart persistence can continue.

No Audio Sync, Expo Sync, or AI feature work has started.
